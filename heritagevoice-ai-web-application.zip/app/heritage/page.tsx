import HeritageVoiceApp from "../page";

export default function HeritageRoutePage() {
  return <HeritageVoiceApp />;
}
