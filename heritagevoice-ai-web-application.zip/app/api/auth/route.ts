import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  clearAuthCookies,
  clearServerSession,
  getAuthSession,
  getAuthUser,
  hashPassword,
  persistServerSession,
  setAuthCookies,
  signToken,
} from "@/lib/auth";
import {
  ensureDemoAccountsValid,
  ensureSeeded,
  verifyOrRepairDemoPassword,
} from "@/lib/seed";
import { isGroqConfigured } from "@/lib/ai";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await ensureSeeded();
    const { user, token } = await getAuthSession(req);
    const res = NextResponse.json({
      ok: true,
      user,
      token: token || null,
      aiMode: isGroqConfigured() ? "groq-live" : "demo-fallback",
    });

    if (user && token) {
      setAuthCookies(res, token, req);
    }

    return res;
  } catch (error) {
    console.error("GET /api/auth error:", error);
    return NextResponse.json(
      {
        ok: false,
        user: null,
        token: null,
        aiMode: "demo-fallback",
        error: "Failed to verify session",
      },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    await ensureDemoAccountsValid();
    const body = await req.json();
    const { action } = body;

    if (action === "register") {
      const { name, email, password, region, preferredLanguage } = body;
      if (!name || !email || !password) {
        return NextResponse.json(
          { error: "Name, email, and password are required." },
          { status: 400 }
        );
      }
      if (String(password).length < 6) {
        return NextResponse.json(
          { error: "Password must be at least 6 characters." },
          { status: 400 }
        );
      }

      const cleanEmail = String(email).trim().toLowerCase();
      const existing = await db
        .select()
        .from(users)
        .where(eq(users.email, cleanEmail))
        .limit(1);

      if (existing.length > 0) {
        return NextResponse.json(
          { error: "An account with this email already exists." },
          { status: 409 }
        );
      }

      const passwordHash = hashPassword(String(password));
      const [created] = await db
        .insert(users)
        .values({
          name: String(name).trim(),
          email: cleanEmail,
          passwordHash,
          region: region ? String(region).trim() : "Konkan & Sahyadri",
          preferredLanguage: preferredLanguage
            ? String(preferredLanguage).trim()
            : "Marathi",
          role: "user",
          bio: `Community contributor preserving ${
            region || "regional"
          } heritage and ${preferredLanguage || "local"} dialect traditions.`,
        })
        .returning();

      const token = signToken({
        userId: created.id,
        email: created.email,
        role: created.role,
      });

      await persistServerSession(token, created.id, req);

      const { passwordHash: _removed, ...safeUser } = created;
      const res = NextResponse.json({ ok: true, user: safeUser, token });
      setAuthCookies(res, token, req);
      return res;
    }

    if (action === "login") {
      const { email, password } = body;
      if (!email || !password) {
        return NextResponse.json(
          { error: "Email and password are required." },
          { status: 400 }
        );
      }

      const cleanEmail = String(email).trim().toLowerCase();
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.email, cleanEmail))
        .limit(1);

      if (!user) {
        return NextResponse.json(
          { error: "Invalid email or password." },
          { status: 401 }
        );
      }

      const passwordValid = await verifyOrRepairDemoPassword(
        cleanEmail,
        String(password),
        user.passwordHash,
        user.id
      );

      if (!passwordValid) {
        return NextResponse.json(
          { error: "Invalid email or password." },
          { status: 401 }
        );
      }

      const token = signToken({
        userId: user.id,
        email: user.email,
        role: user.role,
      });

      await persistServerSession(token, user.id, req);

      const { passwordHash: _removed, ...safeUser } = user;
      const res = NextResponse.json({ ok: true, user: safeUser, token });
      setAuthCookies(res, token, req);
      return res;
    }

    if (action === "logout") {
      await clearServerSession();
      const res = NextResponse.json({ ok: true, user: null });
      clearAuthCookies(res, req);
      return res;
    }

    if (action === "forgot-password") {
      const { email, newPassword } = body;
      if (!email || !newPassword) {
        return NextResponse.json(
          { error: "Please provide your registered email and a new password." },
          { status: 400 }
        );
      }
      if (String(newPassword).length < 6) {
        return NextResponse.json(
          { error: "New password must be at least 6 characters long." },
          { status: 400 }
        );
      }

      const cleanEmail = String(email).trim().toLowerCase();
      const [existing] = await db
        .select()
        .from(users)
        .where(eq(users.email, cleanEmail))
        .limit(1);

      if (!existing) {
        return NextResponse.json(
          { error: "No account found matching that email address." },
          { status: 404 }
        );
      }

      const passwordHash = hashPassword(String(newPassword));
      await db
        .update(users)
        .set({ passwordHash })
        .where(eq(users.id, existing.id));

      return NextResponse.json({
        ok: true,
        message: "Password updated successfully. You may now sign in.",
      });
    }

    if (action === "update-profile") {
      const authUser = await getAuthUser(req);
      if (!authUser) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
      }

      const { name, region, preferredLanguage, bio } = body;
      const [updated] = await db
        .update(users)
        .set({
          name: name ? String(name).trim() : authUser.name,
          region: region ? String(region).trim() : authUser.region,
          preferredLanguage: preferredLanguage
            ? String(preferredLanguage).trim()
            : authUser.preferredLanguage,
          bio: bio !== undefined ? String(bio).trim() : authUser.bio,
        })
        .where(eq(users.id, authUser.id))
        .returning();

      const { passwordHash: _removed, ...safeUser } = updated;
      return NextResponse.json({ ok: true, user: safeUser });
    }

    return NextResponse.json({ error: "Unknown auth action" }, { status: 400 });
  } catch (error) {
    console.error("POST /api/auth error:", error);
    return NextResponse.json(
      { error: "Internal server error processing authentication." },
      { status: 500 }
    );
  }
}
