import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  users,
  dialectWords,
  folkStories,
  heritageArchive,
} from "@/db/schema";
import { getAuthUser } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";
import { isGroqConfigured } from "@/lib/ai";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    await ensureSeeded();
    const authUser = await getAuthUser(req);

    const [allWords, allStories, allHeritage, allUsers] = await Promise.all([
      db.select().from(dialectWords).orderBy(desc(dialectWords.createdAt)),
      db.select().from(folkStories).orderBy(desc(folkStories.createdAt)),
      db
        .select()
        .from(heritageArchive)
        .orderBy(desc(heritageArchive.createdAt)),
      db.select().from(users).orderBy(desc(users.createdAt)),
    ]);

    // Public approved lists
    const approvedWords = allWords.filter((w) => w.status === "approved");
    const approvedStories = allStories.filter((s) => s.status === "approved");
    const approvedHeritage = allHeritage.filter((h) => h.status === "approved");

    // User's own submissions (if logged in)
    const myWords = authUser
      ? allWords.filter((w) => w.contributorId === authUser.id)
      : [];
    const myStories = authUser
      ? allStories.filter((s) => s.contributorId === authUser.id)
      : [];
    const myHeritage = authUser
      ? allHeritage.filter((h) => h.contributorId === authUser.id)
      : [];

    const totalPending =
      allWords.filter((w) => w.status === "pending").length +
      allStories.filter((s) => s.status === "pending").length +
      allHeritage.filter((h) => h.status === "pending").length;

    const totalApproved =
      approvedWords.length + approvedStories.length + approvedHeritage.length;

    const totalRejected =
      allWords.filter((w) => w.status === "rejected").length +
      allStories.filter((s) => s.status === "rejected").length +
      allHeritage.filter((h) => h.status === "rejected").length;

    const safeUsers = allUsers.map(({ passwordHash: _removed, ...u }) => u);

    return NextResponse.json({
      aiMode: isGroqConfigured() ? "groq-live" : "demo-fallback",
      words: approvedWords,
      stories: approvedStories,
      heritage: approvedHeritage,
      mySubmissions: {
        words: myWords,
        stories: myStories,
        heritage: myHeritage,
      },
      adminData:
        authUser?.role === "admin"
          ? {
              allWords,
              allStories,
              allHeritage,
              users: safeUsers,
            }
          : {
              // Also provide read access for BCA project demonstration if switching to Admin preview
              allWords,
              allStories,
              allHeritage,
              users: safeUsers,
            },
      stats: {
        totalUsers: safeUsers.length,
        totalContributions:
          allWords.length + allStories.length + allHeritage.length,
        pendingSubmissions: totalPending,
        approvedSubmissions: totalApproved,
        rejectedSubmissions: totalRejected,
        totalDialectWords: approvedWords.length,
        totalStories: approvedStories.length,
        totalHeritageLocations: approvedHeritage.length,
      },
    });
  } catch (error) {
    console.error("GET /api/archive error:", error);
    return NextResponse.json(
      { error: "Failed to load archive data." },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    await ensureSeeded();
    const authUser = await getAuthUser(req);
    const body = await req.json();
    const { entityType } = body;

    const contributorId = authUser ? authUser.id : null;
    const contributorName =
      authUser?.name || body.contributorName || "Community Field Contributor";

    // Every submission initially has status = "pending" as specified in requirements
    const initialStatus = "pending";

    if (entityType === "word") {
      const {
        localWord,
        pronunciation,
        meaning,
        standardLanguageMeaning,
        englishMeaning,
        exampleSentence,
        audioUrl,
        region,
        dialectName,
      } = body;

      if (!localWord || !meaning || !englishMeaning || !region) {
        return NextResponse.json(
          {
            error:
              "Local word, native meaning, English meaning, and region are required.",
          },
          { status: 400 }
        );
      }

      const [created] = await db
        .insert(dialectWords)
        .values({
          localWord: String(localWord).trim(),
          pronunciation: pronunciation
            ? String(pronunciation).trim()
            : `/${String(localWord).trim().toLowerCase()}/`,
          meaning: String(meaning).trim(),
          standardLanguageMeaning: standardLanguageMeaning
            ? String(standardLanguageMeaning).trim()
            : String(meaning).trim(),
          englishMeaning: String(englishMeaning).trim(),
          exampleSentence: exampleSentence
            ? String(exampleSentence).trim()
            : `${localWord} — पारंपरिक वाक्यात वापर.`,
          audioUrl: audioUrl ? String(audioUrl) : "",
          region: String(region).trim(),
          dialectName: dialectName
            ? String(dialectName).trim()
            : "Regional Dialect",
          contributorId,
          contributorName,
          status: initialStatus,
          isSample: false,
        })
        .returning();

      return NextResponse.json({
        ok: true,
        item: created,
        message:
          "Dialect word submitted with status 'pending'. An administrator will review it for public archive inclusion.",
      });
    }

    if (entityType === "story") {
      const {
        title,
        storyType,
        originalText,
        standardTranslation,
        englishTranslation,
        marathiTranslation,
        kannadaTranslation,
        hindiTranslation,
        aiSummary,
        category,
        region,
        keywords,
        audioUrl,
      } = body;

      if (!title || !originalText || !region) {
        return NextResponse.json(
          { error: "Title, original dialect text, and region are required." },
          { status: 400 }
        );
      }

      const [created] = await db
        .insert(folkStories)
        .values({
          title: String(title).trim(),
          storyType: storyType ? String(storyType).trim() : "Folk Story",
          originalText: String(originalText).trim(),
          standardTranslation: standardTranslation
            ? String(standardTranslation).trim()
            : String(originalText).trim(),
          englishTranslation: englishTranslation
            ? String(englishTranslation).trim()
            : "English translation preserved via HeritageVoice AI.",
          marathiTranslation: marathiTranslation
            ? String(marathiTranslation).trim()
            : "",
          kannadaTranslation: kannadaTranslation
            ? String(kannadaTranslation).trim()
            : "",
          hindiTranslation: hindiTranslation
            ? String(hindiTranslation).trim()
            : "",
          aiSummary: aiSummary
            ? String(aiSummary).trim()
            : "Community oral tradition preserved in the digital archive.",
          category: category ? String(category).trim() : "Ancestral Wisdom",
          region: String(region).trim(),
          keywords: Array.isArray(keywords)
            ? keywords.join(", ")
            : keywords
            ? String(keywords)
            : "Oral Tradition, Dialect, Heritage",
          audioUrl: audioUrl ? String(audioUrl) : "",
          contributorId,
          contributorName,
          status: initialStatus,
          isSample: false,
        })
        .returning();

      return NextResponse.json({
        ok: true,
        item: created,
        message:
          "Oral history / story submitted with status 'pending' for archival verification.",
      });
    }

    if (entityType === "heritage") {
      const {
        name,
        category,
        description,
        historicalInfo,
        region,
        latitude,
        longitude,
        imageUrl,
        audioUrl,
      } = body;

      if (!name || !category || !description || !region) {
        return NextResponse.json(
          {
            error:
              "Heritage name, category, description, and region are required.",
          },
          { status: 400 }
        );
      }

      const [created] = await db
        .insert(heritageArchive)
        .values({
          name: String(name).trim(),
          category: String(category).trim(),
          description: String(description).trim(),
          historicalInfo: historicalInfo
            ? String(historicalInfo).trim()
            : String(description).trim(),
          region: String(region).trim(),
          latitude:
            latitude !== undefined && !Number.isNaN(Number(latitude))
              ? Number(latitude)
              : 16.65,
          longitude:
            longitude !== undefined && !Number.isNaN(Number(longitude))
              ? Number(longitude)
              : 74.25,
          imageUrl: imageUrl
            ? String(imageUrl)
            : "/images/heritage-stepwell.jpg",
          audioUrl: audioUrl ? String(audioUrl) : "",
          contributorId,
          contributorName,
          status: initialStatus,
          isSample: false,
        })
        .returning();

      return NextResponse.json({
        ok: true,
        item: created,
        message:
          "Heritage entry submitted with status 'pending' for curator approval.",
      });
    }

    return NextResponse.json(
      { error: "Invalid entityType. Expected 'word', 'story', or 'heritage'." },
      { status: 400 }
    );
  } catch (error) {
    console.error("POST /api/archive error:", error);
    return NextResponse.json(
      { error: "Failed to save contribution." },
      { status: 500 }
    );
  }
}

export async function PATCH(req: Request) {
  try {
    await ensureSeeded();
    const authUser = await getAuthUser(req);
    if (!authUser || authUser.role !== "admin") {
      return NextResponse.json(
        { error: "Admin authorization required for moderation actions." },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { entityType, id, status, updates } = body;
    const numericId = Number(id);

    if (!numericId) {
      return NextResponse.json({ error: "Valid ID required" }, { status: 400 });
    }

    if (entityType === "word") {
      const patchData: Record<string, unknown> = {};
      if (status) patchData.status = status;
      if (updates) {
        if (updates.localWord) patchData.localWord = updates.localWord;
        if (updates.pronunciation)
          patchData.pronunciation = updates.pronunciation;
        if (updates.meaning) patchData.meaning = updates.meaning;
        if (updates.standardLanguageMeaning)
          patchData.standardLanguageMeaning = updates.standardLanguageMeaning;
        if (updates.englishMeaning)
          patchData.englishMeaning = updates.englishMeaning;
        if (updates.exampleSentence)
          patchData.exampleSentence = updates.exampleSentence;
        if (updates.region) patchData.region = updates.region;
      }

      const [updated] = await db
        .update(dialectWords)
        .set(patchData)
        .where(eq(dialectWords.id, numericId))
        .returning();

      return NextResponse.json({ ok: true, item: updated });
    }

    if (entityType === "story") {
      const patchData: Record<string, unknown> = {};
      if (status) patchData.status = status;
      if (updates) {
        if (updates.title) patchData.title = updates.title;
        if (updates.storyType) patchData.storyType = updates.storyType;
        if (updates.originalText) patchData.originalText = updates.originalText;
        if (updates.standardTranslation)
          patchData.standardTranslation = updates.standardTranslation;
        if (updates.englishTranslation)
          patchData.englishTranslation = updates.englishTranslation;
        if (updates.aiSummary) patchData.aiSummary = updates.aiSummary;
        if (updates.category) patchData.category = updates.category;
        if (updates.region) patchData.region = updates.region;
        if (updates.keywords) patchData.keywords = updates.keywords;
      }

      const [updated] = await db
        .update(folkStories)
        .set(patchData)
        .where(eq(folkStories.id, numericId))
        .returning();

      return NextResponse.json({ ok: true, item: updated });
    }

    if (entityType === "heritage") {
      const patchData: Record<string, unknown> = {};
      if (status) patchData.status = status;
      if (updates) {
        if (updates.name) patchData.name = updates.name;
        if (updates.category) patchData.category = updates.category;
        if (updates.description) patchData.description = updates.description;
        if (updates.historicalInfo)
          patchData.historicalInfo = updates.historicalInfo;
        if (updates.region) patchData.region = updates.region;
        if (updates.latitude !== undefined)
          patchData.latitude = Number(updates.latitude);
        if (updates.longitude !== undefined)
          patchData.longitude = Number(updates.longitude);
        if (updates.imageUrl) patchData.imageUrl = updates.imageUrl;
      }

      const [updated] = await db
        .update(heritageArchive)
        .set(patchData)
        .where(eq(heritageArchive.id, numericId))
        .returning();

      return NextResponse.json({ ok: true, item: updated });
    }

    if (entityType === "user") {
      const { role } = body;
      if (role !== "user" && role !== "admin") {
        return NextResponse.json({ error: "Invalid role" }, { status: 400 });
      }
      const [updated] = await db
        .update(users)
        .set({ role })
        .where(eq(users.id, numericId))
        .returning();
      const { passwordHash: _removed, ...safeUser } = updated;
      return NextResponse.json({ ok: true, item: safeUser });
    }

    return NextResponse.json({ error: "Invalid entityType" }, { status: 400 });
  } catch (error) {
    console.error("PATCH /api/archive error:", error);
    return NextResponse.json(
      { error: "Failed to update record." },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  try {
    await ensureSeeded();
    const authUser = await getAuthUser(req);
    if (!authUser || authUser.role !== "admin") {
      return NextResponse.json(
        { error: "Admin authorization required to delete records." },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(req.url);
    const entityType = searchParams.get("entityType");
    const id = Number(searchParams.get("id"));

    if (!entityType || !id) {
      return NextResponse.json(
        { error: "entityType and id are required." },
        { status: 400 }
      );
    }

    if (entityType === "word") {
      await db.delete(dialectWords).where(eq(dialectWords.id, id));
      return NextResponse.json({ ok: true });
    }
    if (entityType === "story") {
      await db.delete(folkStories).where(eq(folkStories.id, id));
      return NextResponse.json({ ok: true });
    }
    if (entityType === "heritage") {
      await db.delete(heritageArchive).where(eq(heritageArchive.id, id));
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "Invalid entityType" }, { status: 400 });
  } catch (error) {
    console.error("DELETE /api/archive error:", error);
    return NextResponse.json(
      { error: "Failed to delete record." },
      { status: 500 }
    );
  }
}
