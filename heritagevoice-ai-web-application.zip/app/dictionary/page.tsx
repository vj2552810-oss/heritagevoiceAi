import HeritageVoiceApp from "../page";

export default function DictionaryRoutePage() {
  return <HeritageVoiceApp />;
}
