import HeritageVoiceApp from "../page";

export default function VoiceRoutePage() {
  return <HeritageVoiceApp />;
}
