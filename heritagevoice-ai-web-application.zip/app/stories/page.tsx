import HeritageVoiceApp from "../page";

export default function StoriesRoutePage() {
  return <HeritageVoiceApp />;
}
