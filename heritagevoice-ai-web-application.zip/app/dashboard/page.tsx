import HeritageVoiceApp from "../page";

export default function DashboardRoutePage() {
  return <HeritageVoiceApp />;
}
