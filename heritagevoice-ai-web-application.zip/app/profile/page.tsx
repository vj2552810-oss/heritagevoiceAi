import HeritageVoiceApp from "../page";

export default function ProfileRoutePage() {
  return <HeritageVoiceApp />;
}
