import HeritageVoiceApp from "../page";

export default function AiSearchRoutePage() {
  return <HeritageVoiceApp />;
}
