import HeritageVoiceApp from "../page";

export default function RegisterRoutePage() {
  return <HeritageVoiceApp />;
}
