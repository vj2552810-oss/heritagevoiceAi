import HeritageVoiceApp from "../page";

export default function LoginRoutePage() {
  return <HeritageVoiceApp />;
}
