import HeritageVoiceApp from "../page";

export default function MapRoutePage() {
  return <HeritageVoiceApp />;
}
